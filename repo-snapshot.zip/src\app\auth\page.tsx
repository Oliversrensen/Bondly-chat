"use client";
import { signIn } from "next-auth/react";
import { useState } from "react";

export default function AuthPage() {
  const [loading, setLoading] = useState<string | null>(null);
  const cb = "/chat";

  async function go(provider: "google" | "github") {
    setLoading(provider);
    await signIn(provider, { callbackUrl: cb });
  }

  return (
    <div className="flex min-h-[calc(100vh-5rem)] items-center justify-center">
      <div className="bg-[#121212] border border-gray-800 rounded-xl p-8 w-full max-w-md shadow-lg space-y-6">
        <h1 className="text-2xl font-bold text-center">Sign in</h1>

        <button
          className="w-full px-4 py-2 rounded-lg bg-[#1a1a1a] border border-gray-700 text-white hover:border-neonBlue hover:text-neonBlue transition"
          onClick={() => go("google")}
          disabled={loading !== null}
        >
          {loading === "google" ? "Redirecting…" : "Continue with Google"}
        </button>

        <p className="text-sm text-gray-400 text-center">
          You’ll be sent back to <span className="text-white">/chat</span> after login.
        </p>
      </div>
    </div>
  );
}
