import Link from "next/link";

export default function Home() {
  return (
    <main className="space-y-6">
      <div className="card p-6">
        <h1 className="text-3xl font-bold">Anonymous Chat</h1>
        <p className="text-text-muted mt-2">
          Match randomly or by shared interests. Upgrade for priority & pro features.
        </p>
        <div className="flex gap-3 mt-4">
          <Link href="/onboarding" className="btn btn-primary">Get Started</Link>
          <Link href="/chat" className="btn btn-ghost">Open Chat</Link>
        </div>
      </div>
    </main>
  );
}
