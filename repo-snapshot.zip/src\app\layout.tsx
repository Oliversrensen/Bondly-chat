import "./../styles/globals.css";
import Link from "next/link";
import React from "react";
import Providers from "./providers";
import dynamic from "next/dynamic";

const AuthButtons = dynamic(() => import("@/components/AuthButtons"), {
  ssr: false,
});

export const metadata = {
  title: "Neon Chat",
  description: "Random or interest-based anonymous chat",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-darkBg text-white font-sans">
        <Providers>
          {/* Header */}
          <header className="sticky top-0 z-40 border-b border-gray-800 bg-[#121212]/70 backdrop-blur">
            <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
              <Link
                href="/"
                className="font-semibold tracking-tight hover:text-neonBlue transition"
              >
                Neon Chat
              </Link>

              <nav className="flex items-center gap-2">
                <Link
                  href="/chat"
                  className="px-3 py-1.5 rounded-lg text-sm text-gray-300 hover:text-neonPink hover:border-neonPink border border-transparent transition"
                >
                  Chat
                </Link>
                <Link
                  href="/pro"
                  className="px-3 py-1.5 rounded-lg text-sm text-gray-300 hover:text-neonGreen hover:border-neonGreen border border-transparent transition"
                >
                  Go Pro
                </Link>
                <AuthButtons />
              </nav>
            </div>
          </header>

          {/* Main */}
          <main className="max-w-5xl mx-auto px-4 py-6">{children}</main>

          {/* Footer */}
          <footer className="mt-8 border-t border-gray-800 text-center text-xs text-gray-500 py-4">
            Built with ❤️ — Neon Chat
          </footer>
        </Providers>
      </body>
    </html>
  );
}
