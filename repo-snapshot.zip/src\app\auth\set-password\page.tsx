"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";

export default function SetPasswordPage() {
  const { data: session, status } = useSession();
  const [hasPassword, setHasPassword] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [current, setCurrent] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const r = await fetch("/api/me");
      if (r.ok) {
        const data = await r.json();
        setHasPassword(!!data.hasPassword);
      } else {
        setHasPassword(false);
      }
    })();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null); setErr(null);
    const body: any = { password };
    if (hasPassword) body.currentPassword = current;
    const res = await fetch("/api/account/password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      setErr(await res.text());
    } else {
      setMsg("Password saved. You can now sign in with email + password.");
    }
  }

  if (status === "loading") return null;
  if (!session) {
    return (
      <div className="card p-6 max-w-md mx-auto space-y-3">
        <p>You need to sign in first.</p>
        <Link href="/auth" className="btn btn-primary mt-2">Go to sign in</Link>
      </div>
    );
  }

  return (
    <div className="card p-6 max-w-md mx-auto space-y-4">
      <h1 className="text-2xl font-bold">{hasPassword ? "Change password" : "Set a password"}</h1>
      <form onSubmit={submit} className="space-y-3">
        {hasPassword && (
          <input
            type="password" className="input" placeholder="Current password"
            value={current} onChange={(e)=>setCurrent(e.target.value)} required
          />
        )}
        <input
          type="password" className="input" placeholder="New password (min 8 chars)"
          value={password} onChange={(e)=>setPassword(e.target.value)} required
        />
        <button className="btn btn-primary w-full" type="submit">
          {hasPassword ? "Change password" : "Save password"}
        </button>
      </form>
      {msg && <p className="text-sm text-green-400">{msg}</p>}
      {err && <p className="text-sm text-red-400">{err}</p>}
    </div>
  );
}
