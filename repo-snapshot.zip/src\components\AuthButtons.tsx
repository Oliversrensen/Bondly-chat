"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export default function AuthButtons() {
  const { data: session, status } = useSession();

  if (status === "loading") return <span className="badge">Loading…</span>;
  if (!session) return <Link href="/auth" className="btn btn-ghost">Sign in</Link>;

  return (
    <div className="flex items-center gap-2">
      <span className="badge">Signed in</span>
      <button className="btn btn-ghost" onClick={() => signOut({ callbackUrl: "/" })}>
        Sign out
      </button>
    </div>
  );
}
