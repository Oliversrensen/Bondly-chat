import { NextRequest, NextResponse } from "next/server";
import { redis } from "@/lib/redis";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth-full";
import { randomUUID } from "crypto";
import { pickBestByInterest } from "@/lib/matcher";

export const runtime = "nodejs";

const SELF_MATCH_DEV =
  process.env.ALLOW_SELF_MATCH === "true" && process.env.NODE_ENV !== "production";

const PENDING = (u: string) => `match:pending:${u}`;
const PRESENCE = (u: string) => `presence:${u}`;
const QKEY = (mode: "random" | "interest") =>
  mode === "interest" ? "queue:interest" : "queue:random";

async function notifyPair(uidA: string, uidB: string, roomId: string) {
  await Promise.all([
    redis.set(PENDING(uidA), roomId, "EX", 120),
    redis.set(PENDING(uidB), roomId, "EX", 120),
  ]);
}

export async function POST(req: NextRequest) {
  const { mode } = await req.json().catch(() => ({ mode: "random" }));
  if (mode !== "random" && mode !== "interest") {
    return new NextResponse("bad mode", { status: 400 });
  }

  const session = await auth();
  const uid = session?.user?.id;
  if (!uid) return new NextResponse("unauthorized", { status: 401 });

  // Light presence touch (longer TTL, fewer beats)
  await redis.set(PRESENCE(uid), "1", "EX", Number(process.env.PRESENCE_TTL ?? 90));

  const key = QKEY(mode);

  if (mode === "random") {
    // Drain stale heads quickly (bounded)
    for (let i = 0; i < 50; i++) {
      const other = await redis.lpop(key);
      if (!other) break;
      if (other === uid && !SELF_MATCH_DEV) continue;

      // Pipeline a single EXISTS
      const [[, live]] = await redis.pipeline().exists(PRESENCE(other)).exec();
      if (live !== 1) continue; // drop stale

      const roomId = randomUUID().slice(0, 12);
      const match = await prisma.match.create({
        data: { initiatorId: uid, joinerId: other, mode, roomId },
      });
      await notifyPair(uid, other, roomId);
      return NextResponse.json({ queued: false, matchId: match.id, roomId });
    }

    if (SELF_MATCH_DEV) {
      const roomId = randomUUID().slice(0, 12);
      const match = await prisma.match.create({
        data: { initiatorId: uid, joinerId: uid, mode, roomId },
      });
      await notifyPair(uid, uid, roomId);
      return NextResponse.json({ queued: false, matchId: match.id, roomId });
    }

    // Ensure single occurrence for this uid
    await redis.lrem(key, 0, uid);
    await redis.rpush(key, uid);
    return NextResponse.json({ queued: true });
  }

  // INTEREST MODE
  const windowSize = Number(process.env.MATCH_WINDOW ?? 50);
  const waiting = await redis.lrange(key, 0, windowSize - 1);

  // Presence check in ONE pipeline
  const existsPipe = redis.pipeline();
  for (const id of waiting) existsPipe.exists(PRESENCE(id));
  const existsRes = await existsPipe.exec();

  const live: string[] = [];
  waiting.forEach((id, i) => {
    if (id !== uid && existsRes[i]?.[1] === 1) live.push(id);
  });

  const best = await pickBestByInterest(uid, live);
  if (best) {
    await redis.lrem(key, 1, best.otherId);
    const roomId = randomUUID().slice(0, 12);
    const match = await prisma.match.create({
      data: {
        initiatorId: uid,
        joinerId: best.otherId,
        mode,
        roomId,
        similarity: best.sim.score,
      },
    });
    await notifyPair(uid, best.otherId, roomId);
    return NextResponse.json({
      queued: false,
      matchId: match.id,
      roomId,
      similarity: { score: best.sim.score, overlap: best.sim.overlap },
    });
  }

  if (SELF_MATCH_DEV) {
    const roomId = randomUUID().slice(0, 12);
    const match = await prisma.match.create({
      data: { initiatorId: uid, joinerId: uid, mode, roomId, similarity: 1 },
    });
    await notifyPair(uid, uid, roomId);
    return NextResponse.json({
      queued: false,
      matchId: match.id,
      roomId,
      similarity: { score: 1, overlap: 99 },
    });
  }

  await redis.lrem(key, 0, uid);
  await redis.rpush(key, uid);
  return NextResponse.json({ queued: true });
}
