import { NextResponse } from "next/server";
import { auth } from "@/lib/auth-full";
import { redis } from "@/lib/redis";

export const runtime = "nodejs";

export async function POST() {
  const session = await auth();
  const uid = session?.user?.id;
  if (!uid) return new NextResponse("unauthorized", { status: 401 });

  await Promise.all([
    redis.lrem("queue:random", 0, uid),
    redis.lrem("queue:interest", 0, uid),
    redis.del(`match:pending:${uid}`),
  ]);

  return NextResponse.json({ ok: true });
}
