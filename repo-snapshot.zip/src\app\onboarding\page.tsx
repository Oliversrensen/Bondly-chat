"use client";
import { useEffect, useMemo, useState } from "react";

export default function Onboarding() {
  const [gender, setGender] = useState("UNDISCLOSED");
  const [all, setAll] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [filter, setFilter] = useState("");

  // load available interests & user profile
  useEffect(() => {
    (async () => {
      const [allTags, me] = await Promise.all([
        fetch("/api/interests").then((r) => r.json()),
        fetch("/api/me").then((r) => r.json()),
      ]);
      setAll(allTags);
      if (me?.gender) setGender(me.gender);
      if (Array.isArray(me?.interests)) setSelected(me.interests);
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return all.slice(0, 100);
    return all.filter((t: string) => t.includes(q)).slice(0, 100);
  }, [all, filter]);

  function toggle(tag: string) {
    setSelected((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }

  async function save() {
    const res = await fetch("/api/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gender, interests: selected }),
    });
    if (!res.ok) {
      const txt = await res.text();
      alert(`Save failed (${res.status}): ${txt}`);
      return;
    }
    alert("Saved!");
  }

  return (
    <div className="card space-y-6">
      <h1 className="text-2xl font-bold">Your Profile</h1>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Gender select */}
        <div>
          <label className="text-sm text-gray-400">Gender</label>
          <select
            className="input mt-1 w-full"
            value={gender}
            onChange={(e) => setGender(e.target.value)}
          >
            <option>MALE</option>
            <option>FEMALE</option>
            <option>NON_BINARY</option>
            <option>OTHER</option>
            <option>UNDISCLOSED</option>
          </select>
        </div>

        {/* Interests */}
        <div>
          <label className="text-sm text-gray-400">Interests</label>
          <input
            className="input mt-1 w-full"
            placeholder="Search interests…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />

          <div className="flex flex-wrap gap-2 mt-3">
            {filtered.map((tag) => (
              <button
                key={tag}
                onClick={() => toggle(tag)}
                className={`px-3 py-1 rounded-full border text-sm transition 
                  ${
                    selected.includes(tag)
                      ? "bg-[#1f1f1f] border-neonBlue text-neonBlue"
                      : "bg-[#1a1a1a] border-gray-700 text-gray-300 hover:border-neonPink hover:text-neonPink"
                  }`}
              >
                #{tag}
              </button>
            ))}
          </div>

          {selected.length > 0 && (
            <div className="mt-3 text-sm text-gray-400">
              Selected:{" "}
              <span className="text-neonGreen">
                {selected.map((t) => `#${t}`).join(", ")}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Save */}
      <div className="flex gap-2">
        <button className="btn btn-primary" onClick={save}>
          Save
        </button>
      </div>
    </div>
  );
}
