/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: "#0d0d0d",
        neonBlue: "#00f5ff",
        neonPink: "#ff00ff",
        neonGreen: "#39ff14",
      },
      boxShadow: {
        neonBlue: "0 0 10px #00f5ff, 0 0 20px #00f5ff",
        neonPink: "0 0 10px #ff00ff, 0 0 20px #ff00ff",
        neonGreen: "0 0 10px #39ff14, 0 0 20px #39ff14",
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [],
};
