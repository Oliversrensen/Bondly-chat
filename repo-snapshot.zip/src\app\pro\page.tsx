"use client";

export default function Pro() {
  async function upgrade() {
    const res = await fetch("/api/checkout/session", { method: "POST" });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  }

  return (
    <div className="card p-6 space-y-3">
      <h1 className="text-2xl font-bold">Go Pro</h1>
      <p className="text-text-muted">Get priority matching, interest-only pairing and more.</p>
      <button className="btn btn-primary" onClick={upgrade}>Upgrade</button>
    </div>
  );
}
