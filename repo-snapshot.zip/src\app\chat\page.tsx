"use client";

import { useEffect, useRef, useState } from "react";
import io, { Socket } from "socket.io-client";
import { Send, Sparkles, Shuffle } from "lucide-react";

type ChatMessage = { text: string; authorId?: string; at: number };

export default function ChatPage() {
  const [roomId, setRoomId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [status, setStatus] = useState("");
  const [finding, setFinding] = useState(false);

  const socketRef = useRef<Socket | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const hbRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Heartbeat for presence
  function startHeartbeat() {
    if (hbRef.current) return;
    const beat = () =>
      fetch("/api/presence/heartbeat", { method: "POST" }).catch(() => {});
    beat();
    hbRef.current = setInterval(beat, 30000);
  }
  function stopHeartbeat() {
    if (!hbRef.current) return;
    clearInterval(hbRef.current);
    hbRef.current = null;
  }

  // On mount: clear queue
  useEffect(() => {
    fetch("/api/match/leave", { method: "POST" }).catch(() => {});
    const onUnload = () => {
      try {
        navigator.sendBeacon("/api/match/leave");
      } catch {}
    };
    window.addEventListener("beforeunload", onUnload);
    return () => {
      window.removeEventListener("beforeunload", onUnload);
      stopHeartbeat();
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  // Socket connection
  useEffect(() => {
    const s = io(process.env.NEXT_PUBLIC_WS_URL!, {
      transports: ["websocket"],
    });
    socketRef.current = s;
    s.on("message", (m: ChatMessage) => setMessages((prev) => [...prev, m]));
    return () => {
      s.disconnect();
    };
  }, []);

  // Join room
  useEffect(() => {
    if (roomId && socketRef.current) {
      socketRef.current.emit("join_room", { roomId });
      fetch("/api/match/leave", { method: "POST" }).catch(() => {});
      stopHeartbeat();
    }
  }, [roomId]);

  // Auto-scroll
  useEffect(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  function startPolling() {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch("/api/match/pending");
        if (!res.ok) return;
        const data: { roomId: string | null } = await res.json();
        if (data.roomId) {
          setStatus("Matched! Connecting…");
          setRoomId(data.roomId);
          if (pollRef.current) clearInterval(pollRef.current);
        }
      } catch {}
    }, 3000);
  }

  async function start(mode: "random" | "interest") {
    setFinding(true);
    setStatus("Finding a partner…");
    startHeartbeat();

    const res = await fetch("/api/match/enqueue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode }),
    });

    if (!res.ok) {
      const txt = await res.text();
      setFinding(false);
      setStatus(`Match failed (${res.status}): ${txt}`);
      return;
    }

    const data = await res.json();
    if (data.roomId) {
      setStatus("Matched! Connecting…");
      setRoomId(data.roomId);
      setFinding(false);
    } else if (data.queued) {
      setStatus("Waiting in queue…");
      setFinding(false);
      startPolling();
    } else {
      setStatus("No match yet, try again.");
      setFinding(false);
    }
  }

  function send() {
    if (!text.trim() || !roomId || !socketRef.current) return;
    socketRef.current.emit("message", { roomId, text });
    setText("");
  }

  return (
    <div className="grid grid-rows-[auto,1fr,auto] gap-4 h-[calc(90vh-5rem)]">
      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          className="px-4 py-2 rounded-lg bg-[#1a1a1a] border border-gray-700 text-white hover:border-neonBlue hover:text-neonBlue transition flex items-center gap-2 disabled:opacity-50"
          onClick={() => start("random")}
          disabled={finding || !!roomId}
        >
          <Shuffle className="h-4 w-4" /> Random match
        </button>
        <button
          className="px-4 py-2 rounded-lg bg-[#1a1a1a] border border-gray-700 text-white hover:border-neonPink hover:text-neonPink transition flex items-center gap-2 disabled:opacity-50"
          onClick={() => start("interest")}
          disabled={finding || !!roomId}
        >
          <Sparkles className="h-4 w-4" /> Match by interests
        </button>
        <div className="text-sm text-gray-400">{status}</div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="bg-[#121212] border border-gray-800 rounded-xl p-4 overflow-y-auto"
      >
        {messages.length === 0 ? (
          <div className="text-gray-500">No messages yet.</div>
        ) : (
          <div className="space-y-3">
            {messages.map((m, i) => {
              const mine = m.authorId === socketRef.current?.id;
              return (
                <div
                  key={i}
                  className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                    mine
                      ? "ml-auto bg-[#1f1f1f] border border-neonBlue text-white"
                      : "mr-auto bg-[#1f1f1f] border border-neonPink text-white"
                  }`}
                >
                  <span className="block text-xs text-gray-400 mb-1">
                    {new Date(m.at).toLocaleTimeString()}
                  </span>
                  {m.text}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <input
          className="flex-1 px-4 py-2 rounded-lg bg-[#1a1a1a] border border-gray-700 focus:border-neonGreen focus:ring-1 focus:ring-neonGreen outline-none text-white placeholder-gray-500"
          placeholder={
            roomId ? "Type a message…" : "Match first to start chatting"
          }
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={!roomId}
          onKeyDown={(e) => {
            if (e.key === "Enter") send();
          }}
        />
        <button
          className="px-4 py-2 rounded-lg bg-[#1a1a1a] border border-gray-700 text-white hover:border-neonGreen hover:text-neonGreen transition flex items-center justify-center disabled:opacity-50"
          onClick={send}
          disabled={!roomId || !text.trim()}
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
