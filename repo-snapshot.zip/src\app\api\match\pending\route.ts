import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { redis } from "@/lib/redis";

export async function GET() {
  const session = await auth();
  const uid = session?.user?.id;
  if (!uid) return new NextResponse("unauthorized", { status: 401 });

  const key = `match:pending:${uid}`;
  const roomId = await redis.get(key);
  if (!roomId) return NextResponse.json({ roomId: null });

  await redis.del(key); // one-shot
  return NextResponse.json({ roomId });
}
